# -*- coding: utf-8 -*-
"""
Created on Sun Sep 21 13:41:01 2025

@author: JZX
"""

import pandas as pd
import networkx as nx

# 1. 读 CSV
nodes = pd.read_csv("FlashAttention_Case0_Nodes.csv")
edges = pd.read_csv("FlashAttention_Case0_Edges.csv")

# 2. 建图（全部节点 + 全部边）
G = nx.DiGraph()
for _, row in edges.iterrows():
    G.add_edge(int(row.StartNodeId), int(row.EndNodeId))

# 3. 贪心拓扑序：优先 FREE 节点
indeg = {n: G.in_degree(n) for n in G.nodes}
ready = [n for n in G.nodes if indeg[n] == 0]
ready.sort(key=lambda n: 0 if nodes.loc[n, "Op"] == "FREE" else 1)

order = []
while ready:
    node = ready.pop(0)
    order.append(node)
    for succ in G.successors(node):
        indeg[succ] -= 1
        if indeg[succ] == 0:
            ready.append(succ)
            ready.sort(key=lambda n: 0 if nodes.loc[n, "Op"] == "FREE" else 1)

# 4. 模拟 V_stay（只算 UB / L1）
current = 0
max_stay = 0
for node_id in order:
    row = nodes.loc[node_id]
    if row.Op == "ALLOC" and row.Type in {"UB", "L1"}:
        current += row.Size
        max_stay = max(max_stay, current)
    elif row.Op == "FREE" and row.Type in {"UB", "L1"}:
        current -= row.Size

print("最大缓存驻留量（UB+L1）：", max_stay, "字节")

# 5. 写问题一提交文件
with open("FlashAttention_Case0_schedule.txt", "w") as f:
    for nid in order:
        f.write(f"{nid}\n")